# rest-countries-weather

see preview here:
	https://fetch-rest-countries-weather.netlify.app/
